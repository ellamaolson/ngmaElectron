import { AnalysisTool } from './analysisTool'; //'ngma/analysisTool'
new AnalysisTool('./angular-phonecat-copy2');
