App = {};

$(document).ready(function() {
    setTimeout(function() {
        $(".se-pre-con").fadeOut("fast");
    }, 1500);
});